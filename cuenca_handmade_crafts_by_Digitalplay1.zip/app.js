const translations = {
  es: {
    businessName: "Cuenca Handmade Crafts",
    "header.tagline": "Artesanías ecuatorianas en Cuenca",
    "nav.about": "Nosotros",
    "nav.products": "Productos",
    "nav.visit": "Visítanos",
    "nav.contact": "Contacto",
    "hero.title": "Artesanías ecuatorianas en el corazón de Cuenca",
    "hero.subtitle":
      "Descubre macanas Ikat, bolsos, carteras, chaquetas y vestidos hechos a mano por artesanas de Cuenca.",
    "hero.addressShort": "Centro histórico de Cuenca, Casa de la Mujer",
    "buttons.whatsapp": "Chatear por WhatsApp",
    "buttons.directions": "Cómo llegar",
    "buttons.openInMaps": "Abrir en Google Maps",
    "buttons.facebook": "Ver en Facebook",
    "about.title": "Tradición textil de Cuenca",
    "about.subtitle":
      "Cada pieza cuenta una historia de identidad, color y tradición ecuatoriana.",
    "about.p1":
      "En Cuenca Handmade Crafts celebramos el trabajo de artesanas ecuatorianas que han preservado técnicas ancestrales, como el tejido Ikat de las macanas, por generaciones.",
    "about.p2":
      "Nuestros productos son elaborados a mano en pequeños talleres familiares, utilizando fibras de calidad, tintes vivos y diseños inspirados en los paisajes andinos. Cada pieza es única y está pensada para viajeros y amantes del diseño que buscan llevarse un recuerdo auténtico de Cuenca.",
    "about.p3":
      "Te esperamos en el corazón del centro histórico de Cuenca, en la Casa de la Mujer, para que puedas ver, tocar y probar nuestras artesanías.",
    "products.title": "Nuestros productos",
    "products.subtitle":
      "Piezas hechas a mano ideales para uso diario, regalos y recuerdos de viaje.",
    "products.makanas.title": "Macanas Ikat tradicionales",
    "products.makanas.text":
      "Macanas tejidas con la técnica Ikat, reconocidas por sus patrones vibrantes y su elaboración totalmente artesanal. Ideales como chales, mantas decorativas o piezas de colección.",
    "products.bags.title": "Bolsos y carteras hechas a mano",
    "products.bags.text":
      "Bolsos y carteras con diseños contemporáneos y detalles tradicionales, pensados para viajeros y uso diario. Cada pieza combina funcionalidad, color y diseño ecuatoriano.",
    "products.clothing.title": "Chaquetas y vestidos artesanales",
    "products.clothing.text":
      "Chaquetas, ponchos y vestidos con toques artesanales que realzan la identidad ecuatoriana. Diseños cómodos y elegantes para viajar o vestir a diario.",
    "visit.title": "Visítanos en Cuenca",
    "visit.subtitle":
      "Estamos en el centro histórico, a pocos pasos de la Catedral y los principales atractivos turísticos.",
    "visit.addressTitle": "Dirección",
    "visit.hoursTitle": "Recomendado para",
    "visit.point1": "Turistas nacionales e internacionales",
    "visit.point2": "Amantes del diseño y la moda sostenible",
    "visit.point3": "Coleccionistas de textiles y artesanías",
    "contact.title": "Contacto rápido",
    "contact.subtitle":
      "Escríbenos por WhatsApp o síguenos en Facebook para ver más diseños y novedades.",
    "contact.visitTitle": "Visítanos en Cuenca",
    "contact.whatsappTitle": "WhatsApp",
    "footer.message":
      "Artesanías hechas a mano con alma ecuatoriana, para el mundo.",
    "gallery.title": "Galería de artesanías",
    "gallery.subtitle":
      "Cinco escenas del mercado que reflejan el color, la textura y el espíritu de Cuenca.",
    "gallery.badge.market": "Mercado auténtico",
    "gallery.badge.travel": "Recuerdo perfecto",
    "gallery.badge.selection": "Muchas opciones",
    "gallery.badge.color": "Explosión de color",
    "gallery.badge.handmade": "100% hecho a mano",
    "gallery.item1.title": "Canastos que cuentan historias",
    "gallery.item1.text":
      "Cada canasto es tejido a mano por mujeres de la región, mezclando fibras naturales con flores pintadas a mano para darle vida a tu hogar.",
    "gallery.item2.title": "Sombreros para viajar ligero",
    "gallery.item2.text":
      "Sombreros y bolsos ligeros, plegables y resistentes, pensados para acompañarte desde las calles empedradas de Cuenca hasta tu próximo destino.",
    "gallery.item3.title": "Un rincón dedicado al sombrero",
    "gallery.item3.text":
      "Desde el sombrero clásico hasta piezas de diseño, seleccionamos modelos que combinan confort, estilo y tradición ecuatoriana.",
    "gallery.item4.title": "Mandalas tejidos a mano",
    "gallery.item4.text":
      "Tapetes circulares que parecen mandalas, perfectos para dar un punto de color a tu sala, estudio o espacio de meditación.",
    "gallery.item5.title": "Manos que tejen tradición",
    "gallery.item5.text":
      "Detrás de cada sombrero hay horas de trabajo paciente y una historia familiar que se transmite de generación en generación.",
  },
  en: {
    businessName: "Cuenca Handmade Crafts",
    "header.tagline": "Ecuadorian crafts in Cuenca",
    "nav.about": "About",
    "nav.products": "Products",
    "nav.visit": "Visit us",
    "nav.contact": "Contact",
    "hero.title": "Ecuadorian handmade crafts in the heart of Cuenca",
    "hero.subtitle":
      "Discover Ikat macanas, bags, purses, jackets and dresses handmade by artisans from Cuenca.",
    "hero.addressShort": "Historic center of Cuenca, Casa de la Mujer",
    "buttons.whatsapp": "Chat on WhatsApp",
    "buttons.directions": "Get directions",
    "buttons.openInMaps": "Open in Google Maps",
    "buttons.facebook": "View on Facebook",
    "about.title": "Textile tradition of Cuenca",
    "about.subtitle":
      "Every piece tells a story of identity, color and Ecuadorian tradition.",
    "about.p1":
      "At Cuenca Handmade Crafts we celebrate the work of Ecuadorian artisans who have preserved ancestral techniques, such as Ikat weaving for macanas, for generations.",
    "about.p2":
      "Our products are handmade in small family workshops, using quality fibers, vivid dyes and designs inspired by the Andean landscape. Each piece is unique and perfect for travelers and design lovers looking for an authentic memory of Cuenca.",
    "about.p3":
      "Visit us in the heart of Cuenca’s historic center, at Casa de la Mujer, where you can see, touch and try our crafts.",
    "products.title": "Our products",
    "products.subtitle":
      "Handmade pieces ideal for everyday use, gifts and travel mementos.",
    "products.makanas.title": "Traditional Ikat macanas",
    "products.makanas.text":
      "Macanas woven with the Ikat technique, known for their vibrant patterns and fully handcrafted production. Ideal as shawls, decorative throws or collectible pieces.",
    "products.bags.title": "Handmade bags and purses",
    "products.bags.text":
      "Bags and purses with contemporary designs and traditional details, created for travelers and everyday use. Each piece blends functionality, color and Ecuadorian design.",
    "products.clothing.title": "Handmade jackets and dresses",
    "products.clothing.text":
      "Jackets, ponchos and dresses with artisanal touches that highlight Ecuadorian identity. Comfortable, elegant designs for travel or everyday wear.",
    "visit.title": "Visit us in Cuenca",
    "visit.subtitle":
      "We are in the historic center, just a few steps from the Cathedral and the main tourist attractions.",
    "visit.addressTitle": "Address",
    "visit.hoursTitle": "Perfect for",
    "visit.point1": "National and international tourists",
    "visit.point2": "Design and slow fashion lovers",
    "visit.point3": "Collectors of textiles and crafts",
    "contact.title": "Quick contact",
    "contact.subtitle":
      "Send us a WhatsApp message or follow us on Facebook to see more designs and news.",
    "contact.visitTitle": "Visit us in Cuenca",
    "contact.whatsappTitle": "WhatsApp",
    "footer.message":
      "Handmade crafts with an Ecuadorian soul, shared with the world.",
    "gallery.title": "Crafts gallery",
    "gallery.subtitle":
      "Five market scenes that reflect the color, texture and spirit of Cuenca.",
    "gallery.badge.market": "Authentic market",
    "gallery.badge.travel": "Perfect souvenir",
    "gallery.badge.selection": "Many options",
    "gallery.badge.color": "Color explosion",
    "gallery.badge.handmade": "100% handmade",
    "gallery.item1.title": "Baskets that tell stories",
    "gallery.item1.text":
      "Each basket is woven by hand by women from the region, mixing natural fibers with hand‑painted flowers to bring life to your home.",
    "gallery.item2.title": "Hats for light travel",
    "gallery.item2.text":
      "Light, foldable and resistant hats and bags, designed to go with you from Cuenca’s cobblestone streets to your next destination.",
    "gallery.item3.title": "A corner dedicated to hats",
    "gallery.item3.text":
      "From classic hats to designer pieces, we select models that combine comfort, style and Ecuadorian tradition.",
    "gallery.item4.title": "Handwoven mandalas",
    "gallery.item4.text":
      "Circular mats that look like mandalas, perfect to add a touch of color to your living room, studio or meditation space.",
    "gallery.item5.title": "Hands weaving tradition",
    "gallery.item5.text":
      "Behind every hat there are hours of patient work and a family story passed down from generation to generation.",
  },
};

const WHATSAPP_BASE = "https://wa.me/593988873715";

const whatsappMessages = {
  es: "Hola, me gustaría información sobre las artesanías.",
  en: "Hello, I would like more information about your handmade crafts.",
};

function buildWhatsAppLink(lang) {
  const msg = encodeURIComponent(whatsappMessages[lang] || whatsappMessages.es);
  return `${WHATSAPP_BASE}?text=${msg}`;
}

function applyTranslations(lang) {
  const dict = translations[lang] || translations.es;
  document.documentElement.lang = lang;

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    if (dict[key]) {
      el.textContent = dict[key];
    }
  });

  // Update WhatsApp links with language-specific message
  const waHero = document.getElementById("whatsapp-hero");
  const waContact = document.getElementById("whatsapp-contact");
  const link = buildWhatsAppLink(lang);
  if (waHero) waHero.href = link;
  if (waContact) waContact.href = link;

  // Update directions button label specifically (if needed)
  const directions = document.getElementById("directions-hero");
  if (directions && lang === "en") {
    directions.textContent = translations.en["buttons.directions"];
  } else if (directions && lang === "es") {
    directions.textContent = translations.es["buttons.directions"];
  }

  // Update active state on language buttons
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.lang === lang);
  });

  // Persist preference
  try {
    localStorage.setItem("preferredLang", lang);
  } catch {
    // ignore
  }
}

function detectInitialLanguage() {
  try {
    const stored = localStorage.getItem("preferredLang");
    if (stored && translations[stored]) return stored;
  } catch {
    /* ignore */
  }
  const browser = (navigator.language || "es").slice(0, 2).toLowerCase();
  if (translations[browser]) return browser;
  return "es";
}

function initLanguageToggle() {
  const initial = detectInitialLanguage();
  applyTranslations(initial);

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.lang;
      if (translations[lang]) {
        applyTranslations(lang);
      }
    });
  });
}

function initYear() {
  const el = document.getElementById("year");
  if (el) {
    el.textContent = new Date().getFullYear();
  }
}

function initScrollZoom() {
  const images = document.querySelectorAll("main img, .site-header img, .site-footer img");
  if (images.length === 0) return;

  images.forEach((img, index) => {
    img.classList.add("scroll-zoom");
    img.dataset.inView = "false";
    img.style.setProperty("--zoom-delay", `${Math.min(index * 40, 200)}ms`);
  });

  if (!("IntersectionObserver" in window)) {
    // Fallback: just enable a subtle zoom-in state
    images.forEach((img) => img.classList.add("zoom-in"));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        entry.target.dataset.inView = entry.isIntersecting ? "true" : "false";
      });
    },
    {
      threshold: 0.15,
    }
  );

  images.forEach((img) => observer.observe(img));

  let lastScrollY = window.scrollY;
  let ticking = false;

  function onScroll() {
    const currentY = window.scrollY;
    const direction = currentY > lastScrollY ? "down" : "up";
    lastScrollY = currentY;

    if (!ticking) {
      window.requestAnimationFrame(() => {
        images.forEach((img) => {
          if (img.dataset.inView !== "true") return;

          if (direction === "down") {
            img.classList.add("zoom-in");
            img.classList.remove("zoom-out");
          } else {
            img.classList.add("zoom-out");
            img.classList.remove("zoom-in");
          }
        });
        ticking = false;
      });
      ticking = true;
    }
  }

  window.addEventListener("scroll", onScroll, { passive: true });
}

document.addEventListener("DOMContentLoaded", () => {
  initYear();
  initLanguageToggle();
  initScrollZoom();
});